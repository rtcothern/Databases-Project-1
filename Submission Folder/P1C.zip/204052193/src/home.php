<html>
    <head>
        <title>Movies for Days!</title>
    </head>

    <body>
        <div>
            <center><h1>Homepage</h1>
            <h2>The following are pages you may navigate:</h2>
            <div style="background: lightblue; padding:10px;">
            <h3 style="margin-top: 0;">Create additional data</h3>
                <a href="addPerson.php"> Add an Actor or a Director</a> <br/>
                <a href="addMovie.php"> Add a Movie</a> <br/>
                <a href="addMoviePerson.php"> Associate a Movie with an Actor or Director</a><br />
                <a href="addReview.php"> Add a Review to a Movie</a>
            </div>
            <div style="background: lightgreen; padding:10px;">
            <h3 style="margin-top: 0;">Browse existing data</h3>
                <a href="viewActor.php"> View information on an actor</a> <br/>
                <a href="viewMovie.php"> View information on a movie</a>
            </div>
            <div style="background: #CD7F32; padding:10px;">
            <h3 style="margin-top: 0;">Perform a search</h3>
                <a href="search.php"> Search for an Actor or a Director</a>  <br/>
            </div>
            </center>
        </div>
    </body>
</html>