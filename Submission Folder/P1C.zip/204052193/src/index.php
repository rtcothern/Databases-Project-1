<?php
// Redirect to true home page.
header("Location: home.php");
?>