Partners:
     Name: George Chassiakos
      UID: 204052193
    Email: georgecha@ucla.edu

     Name: Ray Cothern
      UID: 604161519
    Email: rtcothern@gmail.com

Some of the work was split up cooperatively by working
on a single computer. Another portion of the work was
divided into individual assignments which were
synchronized over git.

Note: Nothing was changed from the original 1B submission.